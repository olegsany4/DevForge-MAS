===== CacheControl 0.14.3 | Apache-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== PySocks 1.7.1 | BSD =====
Full license text: (external retrieval or cached content not shown here)

===== RapidFuzz 3.14.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== aiogram 3.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== alembic 1.16.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== attrs 25.3.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== build 1.3.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== coverage 7.11.1 | Apache-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== fonttools 4.58.5 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== freezegun 1.5.5 | Apache-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== frozenlist 1.7.0 | Apache-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== identify 2.6.15 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== iniconfig 2.1.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== license-expression 30.4.4 | Apache-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== magic-filter 1.0.12 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== msgpack 1.1.2 | Apache-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== mypy_extensions 1.1.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== pip-requirements-parser 32.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== platformdirs 4.5.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== pydantic 2.9.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== pydantic-settings 2.11.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== pytest-asyncio 1.2.0 | Apache-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== soupsieve 2.7 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== tomli 2.3.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== typing-inspection 0.4.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== urllib3 2.5.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== virtualenv 20.35.3 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @babel/code-frame 7.27.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @babel/helper-validator-identifier 7.28.5 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/cli 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/config-conventional 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/config-validator 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/ensure 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/execute-rule 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/format 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/is-ignored 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/lint 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/load 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/message 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/parse 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/read 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/resolve-extends 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/rules 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/to-lines 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/top-level 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @commitlint/types 19.8.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @types/conventional-commits-parser 5.0.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== @types/node 24.10.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== abbrev 1.1.1 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== ajv 8.17.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== ansi-regex 5.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== ansi-styles 3.2.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== ansi-styles 4.3.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== argparse 2.0.1 | Python-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== array-find-index 1.0.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== array-ify 1.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== asap 2.0.6 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== balanced-match 1.0.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== brace-expansion 1.1.12 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== callsites 3.1.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== chalk 2.4.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== chalk 5.6.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== cliui 8.0.1 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== color-convert 1.9.3 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== color-convert 2.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== color-name 1.1.3 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== color-name 1.1.4 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== compare-func 2.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== concat-map 0.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== conventional-changelog-angular 7.0.0 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== conventional-changelog-conventionalcommits 7.0.2 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== conventional-commits-parser 5.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== cosmiconfig-typescript-loader 6.2.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== cosmiconfig 9.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== dargs 8.1.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== debug 3.2.7 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== debuglog 1.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== dezalgo 1.0.4 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== dot-prop 5.3.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== emoji-regex 8.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== env-paths 2.2.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== error-ex 1.3.4 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== escalade 3.2.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== escape-string-regexp 1.0.5 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== fast-deep-equal 3.1.3 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== find-up 7.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== fs.realpath 1.0.0 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== function-bind 1.1.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== get-caller-file 2.0.5 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== git-raw-commits 4.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== glob 7.2.3 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== global-directory 4.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== graceful-fs 4.2.11 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== has-flag 3.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== hasown 2.0.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== hosted-git-info 2.8.9 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== import-fresh 3.3.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== import-meta-resolve 4.2.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== inflight 1.0.6 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== inherits 2.0.4 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== ini 4.1.1 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== is-arrayish 0.2.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== is-core-module 2.16.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== is-fullwidth-code-point 3.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== is-obj 2.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== is-text-path 2.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== jiti 2.6.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== js-tokens 4.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== js-yaml 4.1.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== json-parse-even-better-errors 2.3.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== json-schema-traverse 1.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== jsonparse 1.3.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== lines-and-columns 1.2.4 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== locate-path 7.2.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== lodash.camelcase 4.3.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== lodash.isplainobject 4.0.6 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== lodash.kebabcase 4.1.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== lodash.merge 4.6.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== lodash.mergewith 4.6.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== lodash.snakecase 4.1.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== lodash.startcase 4.4.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== lodash.uniq 4.5.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== lodash.upperfirst 4.3.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== meow 12.1.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== minimatch 3.1.2 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== minimist 1.2.8 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== mkdirp 0.5.6 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== ms 2.1.3 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== nopt 4.0.3 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== npm-normalize-package-bin 1.0.1 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== once 1.4.0 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== os-homedir 1.0.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== os-tmpdir 1.0.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== osenv 0.1.5 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== p-limit 4.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== p-locate 6.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== parent-module 1.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== parse-json 5.2.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== path-exists 5.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== path-is-absolute 1.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== path-parse 1.0.7 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== picocolors 1.1.1 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== read-installed 4.0.3 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== read-package-json 2.1.2 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== readdir-scoped-modules 1.1.0 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== require-directory 2.1.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== require-from-string 2.0.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== resolve-from 4.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== resolve-from 5.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== resolve 1.22.11 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== semver 5.7.2 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== semver 7.7.3 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== slide 1.1.6 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== spdx-compare 1.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== spdx-correct 3.2.0 | Apache-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== spdx-expression-parse 3.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== spdx-satisfies 4.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== split2 4.2.0 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== string-width 4.2.3 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== strip-ansi 6.0.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== supports-color 5.5.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== supports-preserve-symlinks-flag 1.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== text-extensions 2.4.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== through 2.3.8 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== tinyexec 1.0.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== treeify 1.1.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== typescript 5.9.3 | Apache-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== undici-types 7.16.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== unicorn-magic 0.1.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== util-extend 1.0.3 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== validate-npm-package-license 3.0.4 | Apache-2.0 =====
Full license text: (external retrieval or cached content not shown here)

===== wrap-ansi 7.0.0 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== wrappy 1.0.2 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== y18n 5.0.8 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== yargs-parser 21.1.1 | ISC =====
Full license text: (external retrieval or cached content not shown here)

===== yargs 17.7.2 | MIT =====
Full license text: (external retrieval or cached content not shown here)

===== yocto-queue 1.2.1 | MIT =====
Full license text: (external retrieval or cached content not shown here)

