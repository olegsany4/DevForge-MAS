# pkg init for src/mas/core
__all__: list[str] = []
