# workspace/backend/main.py
from __future__ import annotations

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="DevForge-MAS Demo API")


class ItemIn(BaseModel):
    name: str
    price: float | None = None
    tags: list[str] | None = None


DB: dict[str, dict] = {}


@app.post("/items")
def create_item(item: ItemIn):
    DB[item.name] = item.model_dump()
    return {"ok": True, "item": DB[item.name]}


@app.get("/items/{name}")
def get_item(name: str):
    return DB.get(name, {})
