<!-- markdownlint-disable MD029 -->

# WBS (Work Breakdown Structure)

0) Intake → 1) Researcher → 2) Architect → 3) Planner → 4) Dev → 5) QA → 6) Release
Статус: Stage 1 (Researcher) — FactSheet создан.
<!-- markdownlint-enable MD029 -->
