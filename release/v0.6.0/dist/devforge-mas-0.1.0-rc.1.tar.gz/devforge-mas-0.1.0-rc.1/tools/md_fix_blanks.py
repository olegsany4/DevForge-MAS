# FILE: tools/md_fix_blanks.py
"""
Мини-утилита: нормализует пустые строки в Markdown:
- не более одной подряд (чтобы удовлетворить MD012)
- добавляет пустые строки вокруг заголовков и списков (минимально)
"""

from __future__ import annotations

import sys
from pathlib import Path

# Константы вместо "magic numbers"
MAX_CONSECUTIVE_BLANKS: int = 1
EXIT_BAD_ARGS: int = 2
MIN_ARGS: int = 2  # <script> <files...>


def _ensure_surrounding_blanks(lines: list[str]) -> list[str]:
    """
    Лёгкая нормализация:
    - перед заголовком (# ...) гарантируем пустую строку (если это не начало файла)
    - перед элементом списка ("- ", "* ", "1. ") гарантируем пустую строку
    - после заголовка — гарантируем одну пустую строку
    """
    result: list[str] = []

    def is_header(s: str) -> bool:
        return s.lstrip().startswith("#")

    def is_list_item(s: str) -> bool:
        st = s.lstrip()
        return st.startswith("- ") or st.startswith("* ") or st[:2].isdigit() and st.strip().find(".") == 1

    for line in lines:
        # Пустая строка перед заголовком/списком (если предыдущая строка не пустая и это не начало файла)
        if (is_header(line) or is_list_item(line)) and result and result[-1].strip() != "":
            result.append("")

        result.append(line)

        # После хедера — ровно одна пустая строка (следующий проход схлопнет лишние)
        if is_header(line):
            result.append("")

    return result


def _squash_blank_runs(lines: list[str]) -> list[str]:
    """Сжимает последовательности пустых строк до MAX_CONSECUTIVE_BLANKS."""
    cleaned: list[str] = []
    blank_run = 0
    for line in lines:
        if line.strip() == "":
            blank_run += 1
            if blank_run <= MAX_CONSECUTIVE_BLANKS:
                cleaned.append(line)
        else:
            blank_run = 0
            cleaned.append(line)
    return cleaned


def process_file(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    orig_lines = text.splitlines()
    lines = orig_lines[:]

    # 1) Нормализация “вокруг” заголовков/списков
    lines = _ensure_surrounding_blanks(lines)
    # 2) Сжатие повторов пустых строк (до 1 — под MD012)
    lines = _squash_blank_runs(lines)

    new_text = "\n".join(lines)
    # Гарантируем один завершающий перевод строки
    if not new_text.endswith("\n"):
        new_text += "\n"

    if new_text != text:
        path.write_text(new_text, encoding="utf-8")
        print(f"Fixed blanks in {path}")
        return True
    return False


def main(argv: list[str]) -> int:
    if len(argv) < MIN_ARGS:
        print("Usage: md_fix_blanks.py <files...>")
        return EXIT_BAD_ARGS

    changed = False
    for name in argv[1:]:
        p = Path(name)
        if not p.exists():
            print(f"Skip (not found): {name}")
            continue
        if p.is_dir():
            for sub in p.rglob("*.md"):
                changed |= process_file(sub)
        else:
            changed |= process_file(p)

    return 0 if not changed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
