# В КАКОЙ ФАЙЛ: tools/release_verify.py
#!/usr/bin/env python3
"""
tools/release_verify.py — минимальная верификация релиза перед упаковкой.

Проверяет:
- Наличие ключевых артефактов (compliance, checks, wbs)
- Запуск lint/tests/bandit
- DB-smoke (если SQLITE DB_FILE указан)
Формирует краткий отчет release_report.txt
"""
from __future__ import annotations

import os
import subprocess  # nosec B404 - используем только shell=False для контролируемых команд
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    ROOT / "compliance" / "NOTICE",
    ROOT / "compliance" / "OBLIGATIONS.md",
    ROOT / "compliance" / "THIRD_PARTY_LICENSES.md",
    ROOT / "workspace" / ".checks",
    ROOT / "workspace" / "wbs" / "wbs.json",
]

SAFE_COMMANDS = {
    ("make", "lint"),
    ("pytest", "-q"),
    ("make", "bandit"),
}


def run(cmd: list[str], check: bool = True) -> subprocess.CompletedProcess:
    # Проверяем, что команда из белого списка (минимальная защита от подмены)
    if tuple(cmd) not in SAFE_COMMANDS:
        raise ValueError(f"Command not allowed by release_verify whitelist: {cmd}")
    print(f"[RUN] {' '.join(cmd)}")
    # shell=False по умолчанию — безопасно; входы контролируемы
    return subprocess.run(cmd, cwd=ROOT, check=check)  # nosec B603 - cmd формируется в коде, shell=False


def main() -> int:  # noqa: PLR0915
    missing = [str(p) for p in REQUIRED_FILES if not p.exists()]
    report: list[str] = []

    if missing:
        report.append("[FAIL] Missing required artifacts:\n- " + "\n- ".join(missing))
        print("\n".join(report))
        (ROOT / "release_report.txt").write_text("\n".join(report), encoding="utf-8")
        return 2

    # Lint
    try:
        run(["make", "lint"])
        report.append("[OK] lint")
    except Exception as e:
        report.append(f"[WARN] lint failed or tool missing: {e}")

    # Tests
    try:
        run(["pytest", "-q"])
        report.append("[OK] tests")
    except Exception as e:
        report.append(f"[WARN] tests failed or pytest missing: {e}")

    # Security (bandit)
    try:
        run(["make", "bandit"])
        report.append("[OK] bandit")
    except Exception as e:
        report.append(f"[WARN] bandit failed or tool missing: {e}")

    # Compliance quick check: файлы уже проверили
    report.append("[OK] compliance files present")

    # DB smoke
    db_file = os.environ.get("DB_FILE", "devforge_mas.sqlite3")
    try:
        tool = ROOT / "tools" / "db_smoke_sqlite.py"
        if tool.exists():
            env = os.environ.copy()
            env["DB_FILE"] = db_file
            print(f"[INFO] DB_FILE={db_file}")
            # Явно shell=False; управляема команда — разрешаем # nosec B603
            subprocess.run([sys.executable, "tools/db_smoke_sqlite.py"], cwd=ROOT, check=True, env=env)  # nosec B603
            report.append("[OK] db smoke")
        else:
            report.append("[SKIP] db smoke (tools/db_smoke_sqlite.py not found)")
    except Exception as e:
        report.append(f"[WARN] db smoke failed: {e}")

    # Reproducibility hash (НЕ для безопасности)
    try:
        import hashlib

        try:
            # Py3.9+: помечаем, что не для безопасности (приглушает B324)
            digest = hashlib.md5(usedforsecurity=False)  # type: ignore[call-arg]
        except TypeError:
            # Фолбэк на blake2b (тоже не для безопасности, но современнее)
            digest = hashlib.blake2b(digest_size=16)  # 128-бит для компактности
        for p in sorted(ROOT.rglob("*")):
            if p.is_file():
                s = f"{p.relative_to(ROOT)}:{p.stat().st_size}\n".encode()
                digest.update(s)
        rep_hash = digest.hexdigest()
        report.append(f"[INFO] reproducibility hash: {rep_hash}")
    except Exception as e:
        report.append(f"[WARN] reproducibility hash failed: {e}")

    content = "\n".join(report)
    (ROOT / "release_report.txt").write_text(content, encoding="utf-8")
    print(content)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
