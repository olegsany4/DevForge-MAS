# Changelog\n\nAll notable changes to this project will be documented in this file.\n\n## v0.1.0 — 2025-11-12
- Maintenance release.
