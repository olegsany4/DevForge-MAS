from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

app = FastAPI(title="DevForge-MAS API", version="0.1.0")

WORKSPACE = Path("workspace")
CONTRACTS_PATH = WORKSPACE / "contracts" / "CONTRACTS.json"


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "ok": True,
        "service": "devforge-mas",
        "ts": datetime.now(UTC).isoformat(),
    }


@app.get("/contracts")
def get_contracts() -> JSONResponse:
    if CONTRACTS_PATH.exists():
        try:
            # Возвращаем содержимое как строку в поле raw (без парсинга — контракт может быть большим)
            data = CONTRACTS_PATH.read_text(encoding="utf-8")
            return JSONResponse(content={"ok": True, "raw": data})
        except Exception as e:  # pragma: no cover
            raise HTTPException(status_code=500, detail=f"read error: {e}")
    return JSONResponse(
        content={
            "ok": True,
            "raw": None,
            "note": f"contracts file not found at {CONTRACTS_PATH}",
        }
    )
