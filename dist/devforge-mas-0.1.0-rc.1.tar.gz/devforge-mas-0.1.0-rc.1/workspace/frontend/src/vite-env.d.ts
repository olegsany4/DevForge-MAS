// workspace/frontend/src/vite-env.d.ts
/// <reference types="vite/client" />
