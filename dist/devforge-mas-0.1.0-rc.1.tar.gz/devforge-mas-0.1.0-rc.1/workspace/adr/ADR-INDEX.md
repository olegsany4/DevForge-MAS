# ADR-lite Index

- ADR-0001 Orchestrator Pattern
- ADR-0002 Tech Stack & Packaging
- ADR-0003 Config & Secrets
- ADR-0004 Persistence & Artifacts
- ADR-0005 Logging & Observability
- ADR-0006 Idempotency & Reproducibility
- ADR-0007 Testing Strategy
- ADR-0008 API Surface (HTTP+CLI)
- ADR-0009 Security Baseline
- ADR-0010 Versioning & Releases
