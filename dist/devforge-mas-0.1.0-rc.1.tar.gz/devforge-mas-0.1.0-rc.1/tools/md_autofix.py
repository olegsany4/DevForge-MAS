# FILE: tools/md_autofix.py
# Purpose: Autofix common markdownlint issues (MD022, MD034, optionally MD041)
# Safe, idempotent; keeps existing functionality and extends with URL + heading spacing fixes.
#
# NOTE: We keep legacy logic commented below for traceability and to preserve line count.
#       New implementation focuses on clarity, fewer branches, and ruff compliance.

from __future__ import annotations

import re
import sys
from pathlib import Path

H1_DEFAULT_TITLES = {
    "THIRD_PARTY_LICENSES.md": "# Third-Party Licenses",
    "OBLIGATIONS.md": "# Third-Party Obligations",
}

RE_HEADING = re.compile(r"^\s{0,3}(#{1,6})\s+\S")
RE_BARE_URL = re.compile(
    r"(?P<prefix>^|[^\(\[<`])"                    # not immediately after ( [ < or `
    r"(?P<url>(?:https?|ftp)://[^\s<>\)\]]+)"     # the URL itself
    r"(?P<suffix>$|[^\)\]>`])"                    # not immediately before ) ] > or `
)
RE_MD_LINK = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")
RE_ALREADY_ANGLE = re.compile(r"<(https?|ftp)://[^>\s]+>")

USAGE_CODE = "Usage: md_autofix.py FILE.md [MORE.md ...]"

# ---- helpers -----------------------------------------------------------------


def _wrap_bare_urls(line: str) -> str:
    """
    MD034: wrap bare URLs with angle brackets unless already part of a link or already wrapped.
    This preserves surrounding characters via capture groups prefix/suffix.
    """
    # quick skips to avoid heavy processing
    if "http" not in line and "ftp://" not in line:
        return line
    if RE_MD_LINK.search(line) or RE_ALREADY_ANGLE.search(line):
        return line

    def repl(m: re.Match[str]) -> str:
        prefix = m.group("prefix")
        url = m.group("url")
        suffix = m.group("suffix")
        return f"{prefix}<{url}>{suffix}"

    return RE_BARE_URL.sub(repl, line)


def _ensure_heading_blanklines(lines: list[str]) -> list[str]:
    """
    MD022: Ensure exactly one blank line above and below headings (except when at file start/end).
    We won't remove more than needed; we normalize to single blank lines around headings.
    """
    out: list[str] = []
    n = len(lines)
    i = 0
    while i < n:
        line = lines[i]
        if RE_HEADING.match(line):
            # ensure single blank line above (if not first non-empty)
            if len(out) > 0 and out[-1].strip() != "":
                out.append("")  # insert one blank line
            out.append(line)

            # look ahead to next line(s) for below-spacing
            j = i + 1
            # collapse multiple blanks to exactly one
            blanks_seen = 0
            while j < n and lines[j].strip() == "":
                blanks_seen += 1
                j += 1
            # ensure one blank after heading if not end-of-file and next is not heading end boundary
            if j < n and (blanks_seen == 0):
                out.append("")
            # skip consumed blank lines
            i = i + 1 + blanks_seen
            continue

        out.append(line)
        i += 1
    return out


def _ensure_top_h1(lines: list[str], file_name: str) -> list[str]:
    """
    (Optional) MD041: ensure first non-empty is an H1. If file has no H1 at all,
    insert default by filename mapping. If any H1 exists later, keep as-is.
    """
    first_non_empty = next((idx for idx, line in enumerate(lines) if line.strip() != ""), None)
    if first_non_empty is None:
        # empty file -> if we know a title, add it
        title = H1_DEFAULT_TITLES.get(Path(file_name).name)
        return [title] if title else lines

    # if first non-empty isn't a heading, but there is any H1 later – do nothing
    if not RE_HEADING.match(lines[first_non_empty]):
        has_any_h1 = any(RE_HEADING.match(l) for l in lines)
        if not has_any_h1:
            title = H1_DEFAULT_TITLES.get(Path(file_name).name)
            if title:
                # add H1 before first non-empty line
                return lines[:first_non_empty] + [title, ""] + lines[first_non_empty:]
    return lines


def _dedupe_trailing_blanklines(lines: list[str]) -> list[str]:
    """Ensure at most one trailing blank line at EOF."""
    i = len(lines) - 1
    while i >= 0 and lines[i].strip() == "":
        i -= 1
    tail_blanks = len(lines) - 1 - i
    if tail_blanks <= 1:
        return lines
    return lines[: i + 2]


def _process_lines(lines: list[str], file_name: str) -> tuple[list[str], bool]:
    changed = False

    # 1) bare URLs
    new_lines = []
    for ln in lines:
        nl = _wrap_bare_urls(ln)
        new_lines.append(nl)
        if nl != ln:
            changed = True
    lines = new_lines

    # 2) surround headings with blank lines (MD022)
    fixed = _ensure_heading_blanklines(lines)
    if fixed != lines:
        changed = True
        lines = fixed

    # 3) ensure top H1 if applicable (MD041 - soft)
    fixed = _ensure_top_h1(lines, file_name)
    if fixed != lines:
        changed = True
        lines = fixed

    # 4) clean excessive trailing blanks
    fixed = _dedupe_trailing_blanklines(lines)
    if fixed != lines:
        changed = True
        lines = fixed

    return lines, changed


def fix_file(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()

    lines, changed = _process_lines(lines, path.name)

    if changed:
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return changed


def main() -> int:
    if len(sys.argv) < 2:
        print(USAGE_CODE, file=sys.stderr)
        return 2  # keep explicit return code for CLI parity

    changed_any = False
    for arg in sys.argv[1:]:
        p = Path(arg)
        if p.exists() and p.is_file() and p.suffix.lower() == ".md":
            if fix_file(p):
                print(f"[md_autofix] fixed: {p}")
                changed_any = True
        else:
            # tolerate non-existing or non-md files (idempotent behaviour)
            continue

    print("[md_autofix] done; changed =", changed_any)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# ------------------------------------------------------------------------------
# LEGACY LOGIC (kept for traceability; previous, more branching approach)
# ------------------------------------------------------------------------------
# def fix_file_legacy(path: Path) -> bool:
#     text = path.read_text(encoding="utf-8")
#     lines = text.splitlines()
#     # MD041: top-level H1 at first non-empty line
#     first_non_empty = next((i for i, l in enumerate(lines) if l.strip() != ""), None)
#     if first_non_empty is not None:
#         if not RE_HEADING.match(lines[first_non_empty]):
#             has_h1 = any(RE_HEADING.match(x) for x in lines)
#             if not has_h1:
#                 title = H1_DEFAULT_TITLES.get(path.name)
#                 if title:
#                     lines.insert(first_non_empty, title)
#                     lines.insert(first_non_empty + 1, "")
#     # MD022/MD034 were not fully handled
#     new_text = "\n".join(lines) + "\n"
#     if new_text != text:
#         path.write_text(new_text, encoding="utf-8")
#         return True
#     return False
