from .api import app  # re-export для uvicorn: "src.mas.server:app"

__all__ = ["app"]
